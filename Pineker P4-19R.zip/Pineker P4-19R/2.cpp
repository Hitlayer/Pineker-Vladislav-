#include <iostream>
using namespace std;
void MyFunction() {
    int a, b;
    cout << "a=";
    cin >> a;
    cout << "b=";
    cin >> b;
    for (int i = 1; i <= a; i++)
    {
        for (int j = 1; j <= b; j++)
        {
            cout << "* ";
        }
        cout << endl;
    }

}



int main()
{
    MyFunction();

}
